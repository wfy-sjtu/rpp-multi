#!/usr/bin/env node

/**
 * Portable Extension - Information
 * 
 * This extension is designed to be fully portable and can be distributed
 * and installed in different environments without modification.
 * 
 * Key features for portability:
 * 1. All paths are relative to the extension directory
 * 2. No absolute paths or system-specific paths
 * 3. Standard VS Code extension structure
 * 4. Cross-platform compatible scripts (using npm scripts instead of platform-specific)
 * 5. Minimal external dependencies
 * 
 * Installation methods:
 * - From VSIX package (most portable)
 * - From source using npm
 * - Direct extraction and compilation
 */

console.log("✅ RPP MULTI-3D Extension - Portable Edition");
console.log("Version: 1.0.2");
console.log("");
console.log("This extension is designed for portability across different systems.");
console.log("");
console.log("Supported installation methods:");
console.log("1. Install from VSIX: VS Code Extensions → Install from VSIX");
console.log("2. Install from source: npm install && npm run compile");
console.log("3. Debug mode: npm run watch && Press F5 in VS Code");
console.log("");
