#!/bin/bash

# RPP MULTI-3D Extension Installation Script

echo "================================"
echo "RPP MULTI-3D Extension Installer"
echo "================================"
echo ""

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ Error: npm is not installed. Please install Node.js and npm first."
    exit 1
fi

echo "📦 Installing dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ Error: Failed to install dependencies"
    exit 1
fi

echo ""
echo "✅ Dependencies installed successfully"
echo ""
echo "🔨 Compiling TypeScript..."
npm run compile

if [ $? -ne 0 ]; then
    echo "❌ Error: Failed to compile TypeScript"
    exit 1
fi

echo ""
echo "✅ TypeScript compiled successfully"
echo ""
echo "================================"
echo "✨ Installation Complete!"
echo "================================"
echo ""
echo "Next steps:"
echo "1. Press F5 in VS Code to run the extension in debug mode"
echo "2. Or run: npm run package"
echo "3. Then: code --install-extension *.vsix"
echo ""
