#!/bin/bash

# Quick Start Script for RPP MULTI-3D Extension

echo "🚀 RPP MULTI-3D Extension - Quick Start"
echo ""

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm not found. Please install Node.js first."
    exit 1
fi

# Check if TypeScript is available
if ! npm ls typescript &> /dev/null; then
    echo "📦 Installing TypeScript locally..."
    npm install
fi

# Build the extension
echo "🔨 Compiling extension..."
npm run compile

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Build successful!"
    echo ""
    echo "📝 Next steps:"
    echo "1. Open VS Code in this directory: code ."
    echo "2. Press F5 to start debugging"
    echo "3. Or run: npm run watch (for watch mode)"
    echo ""
    echo "📦 To package as VSIX: npm run package"
    echo ""
else
    echo "❌ Build failed. Check the errors above."
    exit 1
fi
