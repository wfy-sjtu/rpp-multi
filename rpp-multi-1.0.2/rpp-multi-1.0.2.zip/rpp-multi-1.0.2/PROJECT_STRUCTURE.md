# RPP MULTI-3D Extension - Project Structure

## 项目结构说明 / Project Structure

```
rpp.multi-20260120-1.0.2/
├── src/                          # TypeScript源代码
│   └── extension.ts             # 扩展主文件
├── syntaxes/                     # 语法定义
│   └── rpp.tmLanguage.json      # RPP语言语法高亮定义
├── out/                          # 编译输出（生成）
├── package.json                  # 项目配置和依赖
├── tsconfig.json                 # TypeScript配置
├── language-configuration.json   # VS Code语言配置
├── README.md                      # 项目文档
├── INSTALLATION.md               # 安装指南
├── LICENSE                        # MIT许可证
├── .eslintrc.json                # ESLint配置
├── .gitignore                     # Git忽略文件
├── .vscodeignore                  # 打包时忽略的文件
├── .prettierrc.json              # Prettier代码格式化配置
├── install.sh                     # 安装脚本
├── quickstart.sh                  # 快速开始脚本
└── portable-info.js              # 便携性信息

## 快速命令 / Quick Commands

### 开发 / Development
npm install                    # 安装依赖
npm run compile               # 编译TypeScript
npm run watch                 # 监视模式编译
npm run lint                  # 代码检查

### 打包 / Packaging
npm run package               # 生成VSIX包
npm run vscode:prepublish     # 发布前准备

### 测试 / Testing
npm test                      # 运行测试
npm run pretest               # 测试前准备

## 便携性特性 / Portability Features

✅ 跨平台兼容 - Cross-platform compatible
✅ 相对路径 - Relative paths only
✅ 标准结构 - Standard VS Code extension structure
✅ 无系统依赖 - No system-specific dependencies
✅ 自包含 - Self-contained (except Node.js)
✅ 易于分发 - Easy to distribute as VSIX

## 支持的文件类型 / Supported File Types

- .r      # RPP/MULTI-3D源文件
- .rpp    # RPP源文件（备选）

## 激活事件 / Activation Events

- onLanguage:rpp
- onLanguage:r

## 最低要求 / Minimum Requirements

- VS Code: 1.75.0+
- Node.js: 16.x+
- npm: 8.x+
