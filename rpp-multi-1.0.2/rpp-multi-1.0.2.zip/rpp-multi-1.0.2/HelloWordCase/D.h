typedef float real;

#define D_TIPO_NULO     0
#define D_TIPO_BIT      1
#define D_TIPO_CHAR     2
#define D_TIPO_INT      3
#define D_TIPO_REAL     4
#define D_TIPO_FLOAT    4
#define D_TIPO_DOUBLE   5
#define D_TIPO_FUNCION  6
#define D_TIPO_LISTA    1000

typedef struct self_D {
   int t;
   union {
      int n;
      struct self_D** l;
      char *c;
      int *i;
      real *r;
      double *d;
      struct self_D* (*f)();
   } p;
   int n;
   int l;
   union {
      char *c;
   } aux;
   int (*free)();
} D;

int alloc_count;
int free_count;
int static_count;
int DRun;

/* Defined in basic.r */

void DStart();
void DStop();
char *DMalloc();
char *DRealloc();
void DFree();
void MallocPrint();
void DError();
D* DCreaNulo(); 
D* DCreaChar();
D* DCreaInt();
D* DCreaReal();
D* DCreaDouble();
D* DText();
D* DInt();
D* DReal();
D* DDouble();
D* DCreaFuncion();
D* DCreaLista();
D* DCreaLista1();
D* DCreaLista2();
D* DCreaLista3();
D* DCreaLista4();
D* DCreaLista5();
D* DCreaLista6();
D* DCreaLista7();
D* DCreaLista8();
D* DAmplia();
D* DInserta();
void DLibera();
int DTest();
D* DExec();
D* DAsigna();
D** DGlobal(); 
void DGlobalClear();
#define DLink(a)  ((a)->l++,(a))

/* defined in conversion.r */

D *__char1();
D *__int1();
D *__real1();
D *__double1();
D *__round1();
D *__minus1();
D *__eq_zero1();
D *__ne_zero1();
D *__ge_zero1();
D *__gt_zero1();
#define Char(a)    __char1(a)
#define Int(a)     __int1(a)
#define Real(a)    __real1(a)
#define Double(a)  __double1(a)
#define Round(a)   __round1(a)
#define Minus(a)   __minus1(a)
#define Neg(a)     __eq_zero1(a)

/* defined in binary.r */

D *__add2();
D *__sub2();
D *__mod2();
D *__mul2();
D *__div2();
D *__power2();
D *__and2();
D *__or2 ();
D *__eq2();
D *__ne2();
D *__ge2();
D *__gt2();
D *__le2();
D *__lt2();

#define Add(a,b)  __add2(a,b)
#define Sub(a,b)  __sub2(a,b)
#define Mul(a,b)  __mul2(a,b)
#define Div(a,b)  __div2(a,b)
#define Mod(a,b)  __mod2(a,b)
#define Pow(a,b)  __power2(a,b)
#define Gt(a,b)   __gt2(a,b)
#define Ge(a,b)   __ge2(a,b)
#define Eq(a,b)   __eq2(a,b)
#define Ne(a,b)   __ne2(a,b)
#define Or(a,b)   __or2(a,b)
#define And(a,b)  __and2(a,b)

/* defined in manipulate */

D *__to2();
D *__reinsert3();
D *__extract2();
D *__put_item3();
D *__get_item2();
D *__copy1();
D *__cat2();
D *__coma2();
D *__getsize1();
D *__gettype1();
D *__setsize2();
D *__settype2();
D *__lexeq2();
D *__put_member3();
D *__get_member2();

#define To(a,b)              __to2(a,b)
#define Reinserta(a,b,c)     __reinsert3(a,b,c)
#define Extrae(a,b)          __extract2(a,b)
#define SacaElemento(a,b)    __get_item2(a,b)
#define PoneElemento(a,b,c)  __put_item3(a,b,c)
#define Cat(a,b)             __cat2(a,b)
#define Copy(a)              __copy1(a)
#define Coma(a,b)            __coma2(a,b)
#define GetType(a)           __gettype1(a)
#define GetSize(a)           __getsize1(a)
#define SetType(a,b)         __settype2(a,b)
#define SetSize(a,b)         __setsize2(a,b)
#define LexEq(a,b)           __lexeq2(a,b)
#define PoneItem(a,b,c)      __put_member3(a,b,c)
#define SacaItem(a,b)        __get_member2(a,b)
