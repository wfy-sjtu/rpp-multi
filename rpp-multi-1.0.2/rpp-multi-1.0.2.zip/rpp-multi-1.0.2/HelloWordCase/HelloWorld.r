$-----------------------------------------------------------------------------+
$                                                                             |
$   CASE:       Hello World                                                  |
$                                                                             |
$   Version:    20260118                                                      |
$                                                                             |
$   Written by: Assistant                                                     |
$                                                                             |
$   Abstract:   Simple hello world program in MULTI-3D R syntax              |
$                                                                             |
$-----------------------------------------------------------------------------+






$==============================================================================

local vector_add(a, b)
{
   $ 向量相加函数
   $ 参数: a, b - 两个要相加的向量
   $ 返回值: 两个向量的和
   return(a + b);
}

entry multi3d()
{
   p("Hello World!");
   p("Hello World program executed successfully!");
   
   $ 测试向量相加函数
   p("-"[(1 ... 72)>0]);
   p("Testing vector addition function:");
   
   $ 创建测试向量
   v1 = 1...5;
   v2 = 6...10;
   
   $ 调用向量相加函数
   result = vector_add(v1, v2);
   $ result= v1+v2;
   
   $ 输出结果
   a=1;
   p(encode("Vector 1: %g",a));
   p(encode("Vector 2: %g", v2));  
   p(encode("Sum: %g", result));
   
   display(result);
   
   p("-"[(1 ... 72)>0]);
   p("Hello World program completed");
   p("-"[(1 ... 72)>0]);
}
$==============================================================================