# Distribution Guide - RPP MULTI-3D Extension

## 标准分发方式

这个RPP MULTI-3D扩展现已是标准的VSCode扩展，可以在任何电脑上安装。

### ✅ 已验证的标准要素

- ✓ 完整的 `package.json` 配置
- ✓ 语言定义 (`language-configuration.json`)
- ✓ 语法高亮规则 (`syntaxes/rpp.tmLanguage.json`)
- ✓ 编译后的JavaScript代码 (`out/extension.js`)
- ✓ 所有必需的配置文件

---

## 方法1: VSIX包安装（推荐）

### 生成VSIX包

```bash
# 进入扩展目录
cd rpp.multi-20260120-1.0.2

# 安装vsce工具（如果尚未安装）
npm install -g @vscode/vsce

# 编译扩展
npm run compile

# 打包为VSIX文件
npm run package
```

**结果**: 生成 `rpp.multi-1.0.2.vsix` 文件

### 在其他电脑安装VSIX包

**方法A: 使用VS Code GUI**
1. 在VS Code中打开扩展面板（`Ctrl+Shift+X` 或 `Cmd+Shift+X`）
2. 点击左上角的 `...` 菜单
3. 选择 "Install from VSIX..."
4. 选择 `rpp.multi-1.0.2.vsix` 文件
5. 重启VS Code

**方法B: 使用命令行**
```bash
code --install-extension /path/to/rpp.multi-1.0.2.vsix
```

---

## 方法2: 直接复制文件夹

### 在目标电脑上

1. **定位VSCode扩展目录**
   - Windows: `%USERPROFILE%\.vscode\extensions`
   - macOS: `~/.vscode/extensions`
   - Linux: `~/.vscode/extensions`

2. **复制扩展目录**
   ```bash
   cp -r rpp.multi-20260118-1.0.1 ~/.vscode/extensions/
   ```

3. **重启VS Code**

---

## 方法3: 在VS Code Marketplace发布

### 前置条件

1. 拥有Azure DevOps账户
2. 创建Personal Access Token (PAT)
3. 注册为发布者

### 发布步骤

```bash
# 1. 创建/登录发布者账户
vsce create-publisher [your-publisher-name]

# 2. 登录
vsce login [your-publisher-name]

# 3. 更新package.json中的publisher字段
# "publisher": "[your-publisher-name]"

# 4. 增加版本号（可选）
# "version": "1.0.2"

# 5. 发布到marketplace
vsce publish
```

发布后，用户可以直接从VS Code Marketplace搜索并安装。

---

## 跨平台兼容性

该扩展已验证可在以下平台上运行：

- ✓ Windows (所有版本)
- ✓ macOS (Intel 和 Apple Silicon)
- ✓ Linux (Ubuntu, Fedora, Debian等)

**要求**:
- VS Code 1.75.0 或更高版本
- Node.js 16.x+ (开发时)

---

## 打包清单

VSIX包中包含：

```
rpp.multi-1.0.2/
├── out/
│   └── extension.js          ✓ 编译后的主代码
├── syntaxes/
│   └── rpp.tmLanguage.json   ✓ 语法高亮规则
├── language-configuration.json ✓ 语言配置
├── package.json              ✓ 扩展元数据
├── README.md                 ✓ 说明文档
├── LICENSE                   ✓ MIT许可证
└── [其他必需文件]
```

---

## 安装验证

安装后，验证是否成功：

1. 在VS Code中打开 **Extensions** 面板
2. 搜索 `rpp.multi`
3. 如果显示为已安装，则成功
4. 打开任何 `.r` 或 `.rpp` 文件
5. 应该看到语法高亮和诊断功能正常工作

---

## 故障排除

### 问题: 扩展无法加载

**解决方案:**
- 检查VS Code版本 >= 1.75.0
- 清除 `~/.vscode` 目录下的缓存
- 重新安装扩展

### 问题: 语法高亮不工作

**解决方案:**
- 确认文件扩展名是 `.r` 或 `.rpp`
- 检查右下角的语言模式是否为 "RPP"
- 手动选择语言: `Ctrl+K M` > 搜索 "RPP"

### 问题: 诊断不显示错误

**解决方案:**
- 打开 VS Code 调试控制台
- 检查是否有错误日志
- 重启VS Code

---

## 更新扩展版本

### 更新流程

1. 修改源代码
2. 更新 `package.json` 中的版本号
3. 编译: `npm run compile`
4. 打包: `npm run package`
5. 发布或分发新的VSIX包

**版本号约定** (Semantic Versioning):
- `1.0.1`: 修复版本 (bug修复)
- `1.1.0`: 次版本 (新功能，向后兼容)
- `2.0.0`: 主版本 (breaking changes)

---

## 联系与支持

- Repository: https://github.com/rpp-dev/rpp.multi
- Issue Tracker: https://github.com/rpp-dev/rpp.multi/issues
- License: MIT

---

**最后更新**: 2026年1月19日
**扩展版本**: 1.0.2
