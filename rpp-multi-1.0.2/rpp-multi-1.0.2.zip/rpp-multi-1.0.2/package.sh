#!/bin/bash

# RPP MULTI-3D Extension Packaging Script
# 用于创建可分发的VSIX包

set -e

EXTENSION_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION=$(grep '"version"' "$EXTENSION_DIR/package.json" | head -1 | sed 's/.*"version": "\([^"]*\)".*/\1/')

echo "========================================="
echo "RPP MULTI-3D Extension Packager"
echo "========================================="
echo ""
echo "版本: $VERSION"
echo "目录: $EXTENSION_DIR"
echo ""

# 检查是否安装了vsce
if ! command -v vsce &> /dev/null; then
    echo "❌ vsce 未安装"
    echo ""
    echo "安装方法:"
    echo "  npm install -g @vscode/vsce"
    echo ""
    exit 1
fi

# 检查node_modules
if [ ! -d "$EXTENSION_DIR/node_modules" ]; then
    echo "📦 安装依赖..."
    cd "$EXTENSION_DIR"
    npm install
fi

# 编译TypeScript
echo "🔨 编译TypeScript..."
cd "$EXTENSION_DIR"
npm run compile

# 打包VSIX
echo "📦 打包扩展..."
cd "$EXTENSION_DIR"
vsce package --out "rpp.multi-$VERSION.vsix"

echo ""
echo "========================================="
echo "✅ 打包完成！"
echo "========================================="
echo ""
echo "VSIX文件: $EXTENSION_DIR/rpp.multi-$VERSION.vsix"
echo ""
echo "安装方式:"
echo "  1. VS Code: Ctrl+Shift+X → ... → Install from VSIX..."
echo "  2. 命令行: code --install-extension rpp.multi-$VERSION.vsix"
echo ""
