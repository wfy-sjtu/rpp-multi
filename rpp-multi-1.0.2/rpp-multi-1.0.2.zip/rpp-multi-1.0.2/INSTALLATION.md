# RPP MULTI-3D Extension Installation Guide

[中文](#中文) | [English](#english)

## 中文

### 系统要求

- Node.js 16.x 或更高版本
- npm 8.x 或更高版本  
- VS Code 1.75.0 或更高版本

### 安装步骤

#### 方法 1: 自动安装（推荐）

```bash
# 1. 进入扩展目录
cd rpp.multi-20260120-1.0.2

# 2. 运行安装脚本
chmod +x install.sh
./install.sh

# 3. 按 F5 在VS Code中调试运行扩展
```

#### 方法 2: 手动安装

```bash
# 1. 进入扩展目录
cd rpp.multi-20260120-1.0.2

# 2. 安装依赖
npm install

# 3. 编译TypeScript
npm run compile

# 4. 在VS Code中打开此目录并按 F5
```

#### 方法 3: 从VSIX包安装

```bash
# 1. 打包扩展
npm run package

# 2. 在VS Code中打开扩展面板（Ctrl+Shift+X）

# 3. 点击"从VSIX安装..."，选择生成的 .vsix 文件
```

### 开发模式运行

```bash
# 编译并监视文件变化
npm run watch

# 在VS Code中按 F5 启动调试会话
```

### 发布到市场

```bash
# 生成VSIX包
npm run package

# 发布（需要VS Code Market Place账户）
vsce publish
```

### 故障排除

**问题：扩展未激活**
- 确保文件类型为 `.r` 或 `.rpp`
- 检查 VS Code 输出面板中的错误信息

**问题：npm install 失败**
- 删除 node_modules 和 package-lock.json
- 重新运行 npm install

**问题：编译失败**
- 确保安装了 TypeScript: `npm install -g typescript`
- 运行 npm run compile

---

## English

### System Requirements

- Node.js 16.x or higher
- npm 8.x or higher
- VS Code 1.75.0 or higher

### Installation Steps

#### Method 1: Automated Installation (Recommended)

```bash
# 1. Navigate to extension directory
cd rpp.multi-20260120-1.0.2

# 2. Run the installation script
chmod +x install.sh
./install.sh

# 3. Press F5 to debug run the extension in VS Code
```

#### Method 2: Manual Installation

```bash
# 1. Navigate to extension directory
cd rpp.multi-20260120-1.0.2

# 2. Install dependencies
npm install

# 3. Compile TypeScript
npm run compile

# 4. Open this directory in VS Code and press F5
```

#### Method 3: Install from VSIX Package

```bash
# 1. Package the extension
npm run package

# 2. Open Extensions panel in VS Code (Ctrl+Shift+X)

# 3. Click "Install from VSIX...", select generated .vsix file
```

### Running in Development Mode

```bash
# Compile and watch for changes
npm run watch

# Press F5 in VS Code to start debug session
```

### Publishing to Marketplace

```bash
# Generate VSIX package
npm run package

# Publish (requires VS Code Marketplace account)
vsce publish
```

### Troubleshooting

**Issue: Extension not activating**
- Ensure file type is `.r` or `.rpp`
- Check VS Code output panel for error messages

**Issue: npm install fails**
- Delete node_modules and package-lock.json
- Re-run npm install

**Issue: Compilation fails**
- Ensure TypeScript is installed: `npm install -g typescript`
- Run npm run compile
- 参数列表行（以 `,` 结尾）
- 函数定义行: `local func_name(args) {`
- 入口点定义行: `entry func_name() {`
- 控制语句: `if`, `else`, `for`, `while`, `do`, `switch`, `case`

## 在您的HelloWorld.r中测试

您的文件中有这些缺少分号的行：

```rpp
v1 = 1...5    $ ← 第38行，需要分号
v2 = 6...10   $ ← 第39行，需要分号
a=1           $ ← 需要分号
```

重启VSCode后打开 `HelloWorld.r`，您应该会看到这些行被标记为错误。

## 故障排除

### 扩展没有激活？

1. 确保已完全重启VSCode
2. 打开 `HelloWorld.r` 文件
3. 打开 VS Code 的输出面板 (`Shift+Cmd+U`)
4. 选择 "RPP Diagnostics" 频道查看日志

### 想要禁用诊断？

1. 打开 VS Code 设置 (`Cmd+,`)
2. 搜索 "RPP"
3. 找到扩展设置并禁用它

## 修改诊断规则

如果需要调整诊断规则，编辑这个文件：

```
/Users/wfyuan/Downloads/myTest/rpp-diagnostics-extension/out/extension.js
```

修改后重启VSCode即可生效。

## 反馈

如有问题或建议，请检查扩展的源代码：

```
/Users/wfyuan/Downloads/myTest/rpp-diagnostics-extension/
```
