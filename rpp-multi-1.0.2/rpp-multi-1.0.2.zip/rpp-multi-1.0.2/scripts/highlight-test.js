const fs = require('fs');
const path = require('path');
const oniguruma = require('vscode-oniguruma');
const vsctm = require('vscode-textmate');

async function main() {
  const repoRoot = path.resolve(__dirname, '..');
  const grammarPath = path.join(repoRoot, 'syntaxes', 'rpp.tmLanguage.json');
  const samplePath = path.join(repoRoot, 'User.r');

  const wasmBin = fs.readFileSync(require.resolve('vscode-oniguruma/release/onig.wasm')).buffer;
  await oniguruma.loadWASM(wasmBin);

  const onigLib = {
    createOnigScanner: (sources) => new oniguruma.OnigScanner(sources),
    createOnigString: (str) => new oniguruma.OnigString(str)
  };

  const registry = new vsctm.Registry({
    onigLib,
    loadGrammar: (scopeName) => {
      if (scopeName === 'source.rpp') {
        const content = fs.readFileSync(grammarPath, 'utf8');
        return vsctm.parseRawGrammar(content, grammarPath);
      }
      return null;
    }
  });

  const grammar = await registry.loadGrammar('source.rpp');
  if (!grammar) {
    console.error('Failed to load grammar');
    process.exit(2);
  }

  const text = fs.readFileSync(samplePath, 'utf8');
  const lines = text.split(/\r?\n/);

  console.log('Line | TokenScopes (start..end => scope)');
  console.log('-----+---------------------------------------');

  let ruleStack = null;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const res = grammar.tokenizeLine(line, ruleStack);
    ruleStack = res.ruleStack;

    const toks = res.tokens.map(t => `${t.startIndex}-${t.endIndex}:${t.scopes.join(',')}`);
    console.log(String(i+1).padStart(4) + ' | ' + toks.join(' | '));
  }
}

main().catch(err => { console.error(err); process.exit(1); });
