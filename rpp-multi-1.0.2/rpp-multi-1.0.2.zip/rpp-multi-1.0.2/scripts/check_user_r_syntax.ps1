# 获取脚本所在目录的父目录（项目根目录）
$scriptDir = Split-Path -Path $PSScriptRoot -Parent
$path = Join-Path -Path $scriptDir -ChildPath "User.r"
if (-not (Test-Path $path)) { Write-Output "File not found: $path"; exit 2 }
$s = Get-Content -Raw $path -ErrorAction Stop
$counts = @{}
$counts['{'] = ($s -split '\{' | Measure-Object).Count - 1
$counts['}'] = ($s -split '\}' | Measure-Object).Count - 1
$counts['('] = ($s -split '\(' | Measure-Object).Count - 1
$counts[')'] = ($s -split '\)' | Measure-Object).Count - 1
$counts['"'] = ($s -split '"'  | Measure-Object).Count - 1
$counts["'"] = ($s -split "'"  | Measure-Object).Count - 1
Write-Output "Counts:"
$counts.GetEnumerator() | Sort-Object Name | ForEach-Object { Write-Output ("  {0} : {1}" -f $_.Name,$_.Value) }
if ($counts['{'] -ne $counts['}']) { Write-Output "Mismatch: curly braces count differs" } else { Write-Output "OK: curly braces matched" }
if ($counts['('] -ne $counts[')']) { Write-Output "Mismatch: parentheses count differs" } else { Write-Output "OK: parentheses matched" }
if (($counts['"'] % 2) -ne 0) { Write-Output "Warning: odd number of double quotes" } else { Write-Output "OK: double quotes appear balanced (naive)" }
if (($counts["'"] % 2) -ne 0) { Write-Output "Warning: odd number of single quotes" } else { Write-Output "OK: single quotes appear balanced (naive)" }
exit 0
