import sys
import os

# 获取脚本所在目录的父目录（项目根目录）
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
p = os.path.join(project_root, 'User.r')
with open(p, encoding='utf-8') as f:
    lines = f.readlines()
paren_stack = []
unmatched_paren_lines = []
single_quote_lines = []
double_quote = False
for i, line in enumerate(lines, start=1):
    # ignore full-line comments starting with $
    stripped = line.lstrip()
    if stripped.startswith('$'):
        continue
    j = 0
    while j < len(line):
        ch = line[j]
        # handle double-quoted strings
        if ch == '"':
            # toggle double quote, but skip escaped \" inside
            # count preceding backslashes
            bs = 0
            k = j-1
            while k >=0 and line[k] == '\\':
                bs += 1
                k -=1
            if bs % 2 == 0:
                double_quote = not double_quote
            j += 1
            continue
        if double_quote:
            j += 1
            continue
        # outside double quotes and non-comment
        if ch == "'":
            single_quote_lines.append(i)
        if ch == '(':
            paren_stack.append((i, j+1))
        elif ch == ')':
            if paren_stack:
                paren_stack.pop()
            else:
                unmatched_paren_lines.append((i, j+1, 'extra_closing'))
        j += 1
# remaining opens
for (lineno, col) in paren_stack:
    unmatched_paren_lines.append((lineno, col, 'unclosed'))
print('Scan results for', p)
if unmatched_paren_lines:
    print('\nParenthesis mismatches:')
    for item in unmatched_paren_lines:
        print('  line {0} col {1} : {2}'.format(*item))
else:
    print('\nParentheses appear balanced')
if single_quote_lines:
    print('\nSingle quote occurrences (lines):')
    # unique sorted
    for ln in sorted(set(single_quote_lines)):
        print('  line', ln)
else:
    print('\nNo single quote occurrences found')
