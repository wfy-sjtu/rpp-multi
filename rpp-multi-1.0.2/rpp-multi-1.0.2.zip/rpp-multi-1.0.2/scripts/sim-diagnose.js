const fs = require('fs');
const path = require('path');

function findCommentIndex(line) {
  let inString = false;
  let escape = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '\\' && !escape) { escape = true; continue; }
    if (ch === '"' && !escape) { inString = !inString; }
    if (ch === '$' && !inString) { return i; }
    escape = false;
  }
  return -1;
}

const repo = path.resolve(__dirname, '..');
const file = path.join(repo, 'User.r');
const txt = fs.readFileSync(file, 'utf8');
const lines = txt.split(/\r?\n/);

const from = 47, to = 49; // 1-based
const issues = [];
for (let li = from-1; li <= to-1; li++) {
  const line = lines[li] || '';
  if (!line.trim()) continue;
  const cidx = findCommentIndex(line);
  const codePart = cidx >= 0 ? line.slice(0, cidx) : line;
  const ct = codePart.trim();
  if (!ct) continue;
  if (!ct.endsWith(';') && !ct.endsWith('{') && !ct.endsWith(',') && !ct.endsWith(':')) {
    // continuation or function detection (simple)
    if (/^[+\-*/%&|<>=]/.test(ct)) continue;
    if (/^\s*(local|entry)\s+[a-zA-Z_][\w]*\s*\([^)]*\)$/.test(ct)) continue;
    issues.push({line: li+1, text: line, codePart: codePart});
  }
}

if (issues.length === 0) {
  console.log('No missing-semicolon diagnostics in lines', from, '-', to);
} else {
  console.log('Diagnostics found:');
  issues.forEach(i => console.log(i.line, '|', i.codePart));
}
