#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const pkgPath = path.join(__dirname, '..', 'package.json');
function pad(n) { return String(n).padStart(2, '0'); }
try {
  const data = fs.readFileSync(pkgPath, 'utf8');
  const pkg = JSON.parse(data);
  const now = new Date();
  // Local datetime: YYYY-MM-DD HH:MM:SS
  const local = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
  pkg.created = local;
  fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n', 'utf8');
  console.log('Updated package.json created ->', local);
  // Also update README compiled time (replace existing line or insert after header)
  try {
    const readmePath = path.join(__dirname, '..', 'README.md');
    let readme = fs.readFileSync(readmePath, 'utf8');
    const compiledLine = `Compiled at: ${local}`;
    if (/^Compiled at:/m.test(readme)) {
      readme = readme.replace(/^Compiled at:.*$/m, compiledLine);
    } else {
      readme = readme.replace(/(# RPP MULTI Language Support\r?\n)/, `$1\n${compiledLine}\n`);
    }
    fs.writeFileSync(readmePath, readme, 'utf8');
    console.log('Updated README.md compiled time ->', local);
  } catch (e) {
    // Non-fatal: continue
    console.warn('Could not update README.md compiled time:', e && e.message ? e.message : e);
  }
} catch (err) {
  console.error('Failed to update package.json created timestamp:', err);
  process.exit(1);
}
