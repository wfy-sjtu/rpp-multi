import * as vscode from 'vscode';

const diagnosticCollection = vscode.languages.createDiagnosticCollection('rpp');

export function activate(context: vscode.ExtensionContext) {
    console.log('RPP Diagnostics extension is now active');

    // 为所有RPP文件类型注册诊断
    vscode.workspace.onDidOpenTextDocument(document => {
        if (isRppFile(document)) {
            diagnoseDocument(document);
        }
    });

    vscode.workspace.onDidChangeTextDocument(event => {
        if (isRppFile(event.document)) {
            diagnoseDocument(event.document);
        }
    });

    vscode.workspace.onDidCloseTextDocument(document => {
        if (isRppFile(document)) {
            diagnosticCollection.delete(document.uri);
        }
    });

    // 诊断所有已打开的文档
    vscode.workspace.textDocuments.forEach(document => {
        if (isRppFile(document)) {
            diagnoseDocument(document);
        }
    });
}

function isRppFile(document: vscode.TextDocument): boolean {
    return document.languageId === 'rpp' || 
           document.fileName.endsWith('.r') || 
           document.fileName.endsWith('.rpp');
}

function diagnoseDocument(document: vscode.TextDocument) {
    const diagnostics: vscode.Diagnostic[] = [];
    const text = document.getText();
    const lines = document.getText().split('\n');

    for (let lineIndex = 0; lineIndex < lines.length; lineIndex++) {
        const line = lines[lineIndex];
        const trimmed = line.trim();

        // 跳过空行。注释可能在行内（以 $ 开始），因此先找到不在字符串内的注释起始位置并截断。
        if (!trimmed) {
            continue;
        }

        // 找到第一个不在双引号字符串内的 `$`，作为注释起始
        let inString = false;
        let escape = false;
        let commentIndex = -1;
        for (let i = 0; i < line.length; i++) {
            const ch = line[i];
            if (ch === '\\' && !escape) {
                escape = true;
                continue;
            }
            if (ch === '"' && !escape) {
                inString = !inString;
            }
            if (ch === '$' && !inString) {
                commentIndex = i;
                break;
            }
            escape = false;
        }

        const codePart = commentIndex >= 0 ? line.slice(0, commentIndex) : line;
        const codeTrimmed = codePart.trim();
        if (!codeTrimmed) {
            // 该行在注释之前没有代码，跳过
            continue;
        }

        // 跳过只有括号的行
        if (/^[{}()[\]]*$/.test(trimmed)) {
            continue;
        }

        // 检查是否缺少分号
        // 允许以分号、左大括号、逗号或冒号结尾的行（冒号表示行继续，语句在后面的行结束）
        if (!codeTrimmed.endsWith(';') && !codeTrimmed.endsWith('{') && !codeTrimmed.endsWith(',') && !codeTrimmed.endsWith(':')) {
            // 检查是否是语句的继续行（以操作符开头）
            if (/^[+\-*/%&|<>=]/.test(codeTrimmed)) {
                continue;
            }

            // 检查是否是函数参数的延续行
            if (/^\s*[a-zA-Z_][\w]*\s*[,)]/.test(codeTrimmed)) {
                continue;
            }

            // 检查是否是函数定义行
            if (/^\s*(local|entry)\s+[a-zA-Z_][\w]*\s*\([^)]*\)$/.test(codeTrimmed)) {
                continue;
            }
            // 如果下一行（跳过空行和注释）以左大括号开始，则视为代码块开始，不报缺少分号
            let nextIndex = lineIndex + 1;
            let hasNextBrace = false;
            while (nextIndex < lines.length) {
                const nextLine = lines[nextIndex];
                const nextTrim = nextLine.trim();
                if (!nextTrim) { nextIndex++; continue; }
                // 找到下一行中注释开始位置（考虑字符串内的 $）
                let inString2 = false;
                let escape2 = false;
                let commentIndex2 = -1;
                for (let i2 = 0; i2 < nextLine.length; i2++) {
                    const ch2 = nextLine[i2];
                    if (ch2 === '\\' && !escape2) { escape2 = true; continue; }
                    if (ch2 === '"' && !escape2) { inString2 = !inString2; }
                    if (ch2 === '$' && !inString2) { commentIndex2 = i2; break; }
                    escape2 = false;
                }
                const nextCodePart = commentIndex2 >= 0 ? nextLine.slice(0, commentIndex2) : nextLine;
                const nextCodeTrim = nextCodePart.trim();
                if (!nextCodeTrim) { nextIndex++; continue; }
                if (nextCodeTrim.startsWith('{')) {
                    // 有左大括号单独在下一行，属于代码块开始，跳过缺少分号诊断
                    hasNextBrace = true;
                }
                break;
            }
            if (hasNextBrace) {
                continue;
            }
            // 进一步向前查看后续几行，合并非注释代码片段，判断是否在后续行能找到语句终止符（例如分号）；
            // 这可以识别像多行冒号分隔列表（例如 fg = 1: 2: ...）的情况，避免误报
            let lookaheadIndex2 = lineIndex + 1;
            const maxLookahead = 10;
            let foundTerminator = false;
            while (lookaheadIndex2 < lines.length && lookaheadIndex2 <= lineIndex + maxLookahead) {
                const nextLine2 = lines[lookaheadIndex2];
                const nextTrim2 = nextLine2.trim();
                if (!nextTrim2) { lookaheadIndex2++; continue; }
                // 找到下一行中注释开始位置（考虑字符串内的 $）
                let inString3 = false;
                let escape3 = false;
                let commentIndex3 = -1;
                for (let i3 = 0; i3 < nextLine2.length; i3++) {
                    const ch3 = nextLine2[i3];
                    if (ch3 === '\\' && !escape3) { escape3 = true; continue; }
                    if (ch3 === '"' && !escape3) { inString3 = !inString3; }
                    if (ch3 === '$' && !inString3) { commentIndex3 = i3; break; }
                    escape3 = false;
                }
                const nextCodePart2 = commentIndex3 >= 0 ? nextLine2.slice(0, commentIndex3) : nextLine2;
                const nextCodeTrim2 = nextCodePart2.trim();
                if (!nextCodeTrim2) { lookaheadIndex2++; continue; }
                // 如果在后续某行找到分号，说明当前行属于一个跨行语句，跳过报错
                if (nextCodeTrim2.endsWith(';') || nextCodeTrim2.indexOf(';') >= 0) {
                    foundTerminator = true;
                    break;
                }
                // 如果后续行以 ':' 开头或以 ':' 结尾，也很可能是同一语句的延续，继续扫描
                if (/^:/.test(nextCodeTrim2) || /:$/.test(nextCodeTrim2)) { lookaheadIndex2++; continue; }
                // 如果后续行以运算符开头，也可能是延续
                if (/^[+\-*/%&|<>=]/.test(nextCodeTrim2)) { lookaheadIndex2++; continue; }
                // 如果遇到看起来像新的赋值或声明（形如 ident =），则停止
                if (/^[a-zA-Z_][\w]*\s*=/.test(nextCodeTrim2)) { break; }
                lookaheadIndex2++;
            }
            if (foundTerminator) {
                continue;
            }
            // 将诊断标记放在代码部分末尾（注释之前）
            const codeStart = codePart.indexOf(codeTrimmed);
            const endCol = codeStart + codeTrimmed.length;
            const startCol = Math.max(0, endCol - 1);

            const range = new vscode.Range(
                new vscode.Position(lineIndex, startCol),
                new vscode.Position(lineIndex, endCol)
            );

            const diagnostic = new vscode.Diagnostic(
                range,
                '语句缺少分号 (;)',
                vscode.DiagnosticSeverity.Error
            );
            diagnostic.code = 'rpp-missing-semicolon';
            diagnostic.source = 'RPP Diagnostics';

            // 提供快速修复：在代码末尾（注释之前）插入分号
            const fix = new vscode.CodeAction('添加分号', vscode.CodeActionKind.QuickFix);
            fix.edit = new vscode.WorkspaceEdit();
            fix.edit.insert(document.uri, new vscode.Position(lineIndex, endCol), ';');
            diagnostic.relatedInformation = [
                new vscode.DiagnosticRelatedInformation(
                    new vscode.Location(document.uri, range),
                    '在此行末尾（注释之前）添加分号'
                )
            ];

            diagnostics.push(diagnostic);
        }
    }

    diagnosticCollection.set(document.uri, diagnostics);
}

export function deactivate() {
    diagnosticCollection.dispose();
}
